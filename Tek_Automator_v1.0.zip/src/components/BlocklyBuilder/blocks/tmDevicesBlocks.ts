/* ===================== tm_devices High-Level Blocks ===================== */

import * as Blockly from 'blockly';

const TM_DEVICES_COLOR = 210; // Blue-purple to distinguish from raw SCPI

// Helper to get device context field (reusable across blocks)
function appendDeviceContextField(this: Blockly.Block) {
  this.appendDummyInput('DEVICE_CONTEXT_INPUT')
      .appendField('Device:')
      .appendField(new Blockly.FieldLabelSerializable('(scope)'), 'DEVICE_CONTEXT');
}

// Save Screenshot Block (tm_devices native method)
Blockly.Blocks['tm_devices_save_screenshot'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📸 Save Screenshot (tm_devices)');
    appendDeviceContextField.call(this);
    this.appendDummyInput()
        .appendField('Filename:')
        .appendField(new Blockly.FieldTextInput('screenshot'), 'FILENAME');
    this.appendDummyInput()
        .appendField('Format:')
        .appendField(new Blockly.FieldDropdown([
          ['PNG', 'PNG'],
          ['JPEG', 'JPEG'],
          ['BMP', 'BMP']
        ]), 'FORMAT');
    this.appendDummyInput()
        .appendField('Colors:')
        .appendField(new Blockly.FieldDropdown([
          ['Normal', 'NORMAL'],
          ['Inverted', 'INVERTED']
        ]), 'COLORS');
    this.appendDummyInput()
        .appendField('Local Folder:')
        .appendField(new Blockly.FieldTextInput(''), 'LOCAL_FOLDER');
    this.appendDummyInput()
        .appendField('Device Folder:')
        .appendField(new Blockly.FieldTextInput(''), 'DEVICE_FOLDER');
    this.appendDummyInput()
        .appendField('Keep Device File:')
        .appendField(new Blockly.FieldCheckbox('FALSE'), 'KEEP_DEVICE_FILE');
    
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(TM_DEVICES_COLOR);
    this.setTooltip('Captures a screenshot using the instrument\'s native method.\nWraps device.save_screenshot() - tm_devices only.');
    this.setHelpUrl('');
  }
};

// FastFrame Enable Block
Blockly.Blocks['fastframe_enable'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('⚡ FastFrame Enable');
    appendDeviceContextField.call(this);
    this.appendDummyInput()
        .appendField('State:')
        .appendField(new Blockly.FieldDropdown([
          ['ON', 'ON'],
          ['OFF', 'OFF']
        ]), 'STATE');
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(TM_DEVICES_COLOR);
    this.setTooltip('Enable or disable FastFrame acquisition mode');
    this.setHelpUrl('');
  }
};

// FastFrame Set Count Block
Blockly.Blocks['fastframe_set_count'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('⚡ FastFrame Count');
    appendDeviceContextField.call(this);
    this.appendValueInput('COUNT')
        .setCheck('Number')
        .appendField('Count:');
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(TM_DEVICES_COLOR);
    this.setTooltip('Set the number of FastFrame frames to capture (1-10000)');
    this.setHelpUrl('');
  }
};

// FastFrame Select Frame Block
Blockly.Blocks['fastframe_select_frame'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('⚡ FastFrame Select Frame');
    appendDeviceContextField.call(this);
    this.appendDummyInput()
        .appendField('Channel:')
        .appendField(new Blockly.FieldDropdown([
          ['CH1', 'CH1'],
          ['CH2', 'CH2'],
          ['CH3', 'CH3'],
          ['CH4', 'CH4']
        ]), 'CHANNEL');
    this.appendValueInput('FRAME')
        .setCheck('Number')
        .appendField('Frame:');
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(TM_DEVICES_COLOR);
    this.setTooltip('Select a specific FastFrame for processing');
    this.setHelpUrl('');
  }
};

// Search Configure Edge Block
Blockly.Blocks['search_configure_edge'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🔍 Search Configure Edge');
    appendDeviceContextField.call(this);
    this.appendDummyInput()
        .appendField('Search:')
        .appendField(new Blockly.FieldDropdown([
          ['Search 1', '1'],
          ['Search 2', '2']
        ]), 'SEARCH_NUM');
    this.appendDummyInput()
        .appendField('Source:')
        .appendField(new Blockly.FieldDropdown([
          ['CH1', 'CH1'],
          ['CH2', 'CH2'],
          ['CH3', 'CH3'],
          ['CH4', 'CH4']
        ]), 'SOURCE');
    this.appendDummyInput()
        .appendField('Slope:')
        .appendField(new Blockly.FieldDropdown([
          ['Falling', 'FALL'],
          ['Rising', 'RISE']
        ]), 'SLOPE');
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(TM_DEVICES_COLOR);
    this.setTooltip('Configure edge search on a channel');
    this.setHelpUrl('');
  }
};

// Search Query Total Block
Blockly.Blocks['search_query_total'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🔍 Search Query Total');
    appendDeviceContextField.call(this);
    this.appendDummyInput()
        .appendField('Search:')
        .appendField(new Blockly.FieldDropdown([
          ['Search 1', '1'],
          ['Search 2', '2']
        ]), 'SEARCH_NUM');
    this.appendDummyInput()
        .appendField('Store in:')
        .appendField(new Blockly.FieldVariable('search_total'), 'VARIABLE');
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(TM_DEVICES_COLOR);
    this.setTooltip('Query the total number of search results found');
    this.setHelpUrl('');
  }
};

// Measurement Immediate Block
Blockly.Blocks['measurement_immediate'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📊 Immediate Measurement');
    appendDeviceContextField.call(this);
    this.appendDummyInput()
        .appendField('Type:')
        .appendField(new Blockly.FieldDropdown([
          ['Peak-to-Peak', 'PK2PK'],
          ['RMS', 'RMS'],
          ['Frequency', 'FREQUENCY'],
          ['Period', 'PERIOD'],
          ['Mean', 'MEAN'],
          ['Amplitude', 'AMPLITUDE']
        ]), 'TYPE');
    this.appendDummyInput()
        .appendField('Source:')
        .appendField(new Blockly.FieldDropdown([
          ['CH1', 'CH1'],
          ['CH2', 'CH2'],
          ['CH3', 'CH3'],
          ['CH4', 'CH4']
        ]), 'SOURCE');
    this.appendDummyInput()
        .appendField('Store in:')
        .appendField(new Blockly.FieldVariable('measurement'), 'VARIABLE');
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(TM_DEVICES_COLOR);
    this.setTooltip('Perform an immediate measurement and store the result');
    this.setHelpUrl('');
  }
};

// Acquisition Reset Block
Blockly.Blocks['acquisition_reset'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🔄 Reset Acquisition');
    appendDeviceContextField.call(this);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(120); // Green
    this.setTooltip('Reset acquisition state (ACQuire:STATE OFF) - required before starting new acquisition');
    this.setHelpUrl('');
  }
};
