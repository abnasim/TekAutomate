/* ===================== Browse Commands Modal (Shared Component) ===================== */

import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Search, X, HelpCircle, ChevronDown } from 'lucide-react';
import { CommandDetailModal } from './CommandDetailModal';
import { TriggerAnimation } from './TriggerMascot';

export interface CommandLibraryItem {
  name: string;
  scpi: string;
  description: string;
  category: string;
  subcategory?: string;
  params?: any[];
  example?: string;
  tekhsi?: boolean;
  sourceFile?: string;
  [key: string]: any;
}

export interface BrowseCommandsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (command: CommandLibraryItem) => void;
  commands: CommandLibraryItem[];
  categoryColors: Record<string, string>;
  triggerAnimation?: (anim: TriggerAnimation) => void;
  selectedDeviceFamily?: string;
  setSelectedDeviceFamily?: (family: string) => void;
  deviceFamilies?: Array<{ id: string; label: string; icon: string; description: string; tooltip?: string }>;
  buttonText?: string; // Customizable button text (e.g., "Add", "Add to Block")
  title?: string; // Customizable title (e.g., "Browse Commands", "Select SCPI Command")
}

export const BrowseCommandsModal: React.FC<BrowseCommandsModalProps> = ({ 
  isOpen, 
  onClose, 
  onSelect, 
  commands, 
  categoryColors,
  triggerAnimation,
  selectedDeviceFamily,
  setSelectedDeviceFamily,
  deviceFamilies = [],
  buttonText = 'Add',
  title = 'Browse Commands'
}) => {
  const [search, setSearch] = useState<string>('');
  const [selectedCat, setSelectedCat] = useState<string | null>(null);
  const [selectedCommand, setSelectedCommand] = useState<CommandLibraryItem | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [visibleCount, setVisibleCount] = useState(50);
  const scrollSentinelRef = useRef<HTMLDivElement>(null);
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  // Get categories with command counts (must be before early return)
  const categories = useMemo(() => {
    const catMap = new Map<string, number>();
    commands.forEach(cmd => {
      catMap.set(cmd.category, (catMap.get(cmd.category) || 0) + 1);
    });
    return Array.from(catMap.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [commands]);

  // Filter commands (must be before early return)
  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    
    // Split search into keywords and normalize (remove spaces for fuzzy matching)
    const stopWords = new Set(['and', 'or', 'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'on', 'in', 'at', 'to', 'for', 'of', 'with', 'by', 'from', 'as', 'that', 'this', 'it']);
    const searchKeywords = q.split(/\s+/).filter(kw => kw && !stopWords.has(kw));
    const normalizedQuery = q.replace(/[\s:]/g, ''); // Remove spaces/colons from full query
    
    return commands.filter((cmd) => {
      // Category filtering (always applied)
      const matchesCat = selectedCat === null || cmd.category === selectedCat;
      
      // If no search query, just filter by category
      if (!q) return matchesCat;
      
      // Search across all relevant fields
      const searchableFields = [
        cmd.name,
        cmd.scpi,
        cmd.description,
        cmd.category,
        cmd.example,
        // Arguments text
        (cmd as any).arguments,
        // Parameter names and descriptions
        ...(cmd.params?.map(p => `${p.name} ${p.description || ''} ${p.options?.join(' ') || ''}`) || []),
        // Manual entry fields
        cmd.manualEntry?.arguments,
        cmd.manualEntry?.shortDescription,
        cmd.manualEntry?.commandGroup,
        cmd.manualEntry?.mnemonics?.join(' '),
        // Examples
        ...(cmd.manualEntry?.examples?.map((ex: any) => `${ex.description || ''} ${ex.codeExamples?.scpi?.code || ''}`) || []),
      ].filter(Boolean).map(s => String(s).toLowerCase());
      
      // Create a combined searchable text (with and without spaces for fuzzy matching)
      const combinedText = searchableFields.join(' ');
      const normalizedText = combinedText.replace(/[\s:]/g, ''); // Remove spaces and colons for fuzzy matching
      
      // Strategy 1: Try full query as one fuzzy string (e.g., "search option" matches "searchoption")
      const matchesFullQueryFuzzy = normalizedText.includes(normalizedQuery);
      
      // Strategy 2: Match if ALL keywords are found individually (e.g., "search" AND "option" both present)
      const matchesAllKeywords = searchKeywords.length > 0 && searchKeywords.every(keyword => {
        const normalizedKeyword = keyword.replace(/[\s:]/g, '');
        // Try exact match first (faster), then fuzzy match
        return combinedText.includes(keyword) || normalizedText.includes(normalizedKeyword);
      });
      
      // Match if EITHER strategy succeeds
      const matchesSearch = matchesFullQueryFuzzy || matchesAllKeywords;
      
      // Category filter was already checked at the top
      return matchesSearch && matchesCat;
    });
  }, [commands, search, selectedCat]);

  // Infinite scroll (must be before early return)
  const visibleCommands = useMemo(() => 
    filtered.slice(0, visibleCount),
    [filtered, visibleCount]
  );
  const hasMore = visibleCount < filtered.length;

  // Reset visible count when filters change
  useEffect(() => {
    setVisibleCount(50);
  }, [search, selectedCat]);

  // Infinite scroll observer for CommandBrowser
  useEffect(() => {
    const sentinel = scrollSentinelRef.current;
    if (!sentinel) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore) {
          setVisibleCount(prev => Math.min(prev + 50, filtered.length));
        }
      },
      { threshold: 0.1 }
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [hasMore, filtered.length]);
  
  // Trigger search animation when browser opens
  useEffect(() => {
    if (isOpen && triggerAnimation) {
      triggerAnimation('search');
    }
  }, [isOpen, triggerAnimation]);
  

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }
    };
  }, []);
  
  // Debounced search handler
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearch(value);
    setVisibleCount(50); // Reset visible count on search
    
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }
    
    searchTimeoutRef.current = setTimeout(() => {
      if (triggerAnimation && value.length > 0) {
        triggerAnimation('search');
      }
    }, 300);
  };
  
  if (!isOpen) return null;

  const handleCommandClick = (cmd: CommandLibraryItem, e: React.MouseEvent) => {
    // Check if info icon was clicked
    const target = e.target as HTMLElement;
    if (target.closest('.info-icon') || target.closest('button[data-action="info"]')) {
      e.stopPropagation();
      setSelectedCommand(cmd);
      setShowDetailModal(true);
      return;
    }
    
    // Otherwise, add to flow
    onSelect(cmd);
    onClose();
    if (triggerAnimation) {
      triggerAnimation('success');
    }
  };

  const handleAddFromDetail = (cmd: CommandLibraryItem) => {
    onSelect(cmd);
    setShowDetailModal(false);
    onClose();
    if (triggerAnimation) {
      triggerAnimation('success');
    }
  };

  return (
    <>
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
        <div
          className="bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="p-4 border-b flex items-center justify-between bg-gradient-to-r from-blue-50 to-white">
            <h2 className="text-xl font-bold text-gray-900">{title}</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded transition">
              <X size={20} />
            </button>
          </div>

          {/* Search Bar */}
          <div className="p-4 border-b bg-white sticky top-0 z-10">
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
                <input
                  type="text"
                  placeholder="Search by name, SCPI command, or description..."
                  value={search}
                  onChange={handleSearchChange}
                  className="w-full pl-10 pr-10 py-2.5 text-sm border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  autoFocus
                />
                {search && (
                  <button
                    onClick={() => handleSearchChange({ target: { value: '' } } as any)}
                    className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-600 transition"
                    title="Clear search"
                  >
                    <X size={18} />
                  </button>
                )}
              </div>
              {deviceFamilies.length > 0 && selectedDeviceFamily && setSelectedDeviceFamily && (
                <div className="relative" title={deviceFamilies.find(f => f.id === selectedDeviceFamily)?.tooltip || ''}>
                  <select
                    value={selectedDeviceFamily}
                    onChange={(e) => setSelectedDeviceFamily(e.target.value)}
                    className="appearance-none text-xs pl-4 pr-8 py-2.5 bg-blue-50 border border-blue-200 rounded cursor-pointer hover:bg-blue-100 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    title={deviceFamilies.find(f => f.id === selectedDeviceFamily)?.tooltip || ''}
                  >
                    {deviceFamilies.map(family => (
                      <option key={family.id} value={family.id} title={family.tooltip || ''}>
                        {family.icon} {family.label}
                      </option>
                    ))}
                  </select>
                  <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 text-blue-600 pointer-events-none" />
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-1 overflow-hidden">
            {/* Category Sidebar */}
            <div className="w-64 border-r bg-gray-50 overflow-y-auto">
              <div className="p-3 border-b bg-white">
                <h3 className="text-sm font-semibold text-gray-700 mb-2">Categories</h3>
                <button
                  onClick={() => setSelectedCat(null)}
                  className={`w-full text-left px-3 py-2 text-sm rounded transition ${
                    selectedCat === null
                      ? 'bg-blue-100 text-blue-700 font-medium'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  All ({commands.length})
                </button>
              </div>
              <div className="p-2 space-y-1">
                {categories.map(({ name, count }) => (
                  <button
                    key={name}
                    onClick={() => setSelectedCat(name)}
                    className={`w-full text-left px-3 py-2 text-sm rounded transition flex items-center justify-between ${
                      selectedCat === name
                        ? `${categoryColors[name] || 'bg-blue-100 text-blue-700'} font-medium`
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <span className="truncate">{name}</span>
                    <span className={`text-xs ml-2 ${
                      selectedCat === name ? 'text-blue-600' : 'text-gray-400'
                    }`}>
                      {count}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Command List */}
            <div className="flex-1 flex flex-col overflow-hidden">
              {filtered.length === 0 ? (
                <div className="flex-1 flex items-center justify-center text-gray-500">
                  <div className="text-center">
                    <Search size={48} className="mx-auto mb-4 text-gray-300" />
                    <p className="text-lg font-medium">No commands found</p>
                    <p className="text-sm mt-2">Try adjusting your search or category filter</p>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex-1 overflow-y-auto p-4">
                    <div className="space-y-2">
                      {visibleCommands.map((cmd, idx) => (
                        <div
                          key={`${cmd.scpi}-${idx}`}
                          className="p-3 bg-white border rounded-lg hover:border-blue-400 hover:shadow-md transition cursor-pointer group"
                          onClick={(e) => handleCommandClick(cmd, e)}
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                                <span className="font-semibold text-sm text-gray-900">{cmd.name}</span>
                                <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${categoryColors[cmd.category] || 'bg-gray-100 text-gray-700'}`}>
                                  {cmd.category}
                                </span>
                                {cmd.subcategory && (
                                  <span className="text-xs px-2 py-0.5 bg-blue-50 text-blue-700 rounded border border-blue-200">
                                    {cmd.subcategory}
                                  </span>
                                )}
                                {cmd.tekhsi && (
                                  <span className="text-xs px-2 py-0.5 bg-red-100 text-red-700 rounded border border-red-300">
                                    ⚡ gRPC
                                  </span>
                                )}
                              </div>
                              <div className="text-xs font-mono text-blue-600 mb-1.5 bg-blue-50 px-2 py-1 rounded border border-blue-100">
                                {cmd.scpi}
                              </div>
                              <div className="text-xs text-gray-600 line-clamp-2">
                                {cmd.description || 'No description available.'}
                              </div>
                            </div>
                            <div className="flex items-center gap-2 flex-shrink-0">
                              <button
                                data-action="info"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedCommand(cmd);
                                  setShowDetailModal(true);
                                }}
                                className="p-1.5 hover:bg-gray-100 rounded transition opacity-0 group-hover:opacity-100 info-icon"
                                title="View details"
                              >
                                <HelpCircle size={18} className="text-gray-500" />
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onSelect(cmd);
                                  onClose();
                                  if (triggerAnimation) {
                                    triggerAnimation('success');
                                  }
                                }}
                                className="px-3 py-1.5 bg-blue-600 text-white text-xs font-medium rounded hover:bg-blue-700 transition opacity-0 group-hover:opacity-100"
                              >
                                {buttonText}
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                      
                      {/* Infinite scroll sentinel - INSIDE scrollable container */}
                      <div 
                        ref={scrollSentinelRef} 
                        className="py-4 text-center"
                      >
                        <div className="text-sm text-gray-500">
                          {hasMore ? (
                            <span className="flex items-center justify-center gap-2">
                              <span className="animate-pulse">Loading more...</span>
                              <span className="text-gray-400">({visibleCommands.length} of {filtered.length})</span>
                            </span>
                          ) : (
                            <span>Showing all {filtered.length} commands</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Command Detail Modal */}
      <CommandDetailModal
        isOpen={showDetailModal}
        onClose={() => {
          setShowDetailModal(false);
          setSelectedCommand(null);
        }}
        command={selectedCommand}
        onAddToFlow={handleAddFromDetail}
        categoryColor={selectedCommand ? (categoryColors[selectedCommand.category] || 'bg-blue-100 text-blue-700 border-blue-300') : undefined}
      />
    </>
  );
};
