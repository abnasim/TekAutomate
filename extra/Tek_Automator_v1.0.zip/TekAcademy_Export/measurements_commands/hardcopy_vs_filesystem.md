# Hardcopy vs. Filesystem: Two Ways to Get an Image

**Category:** measurements_commands
**ID:** hardcopy_vs_filesystem

---

Hardcopy sends image data directly over the connection as bytes.

Advantages:

• No need to manage files on scope

• Works on all instruments

Save image to scope's disk, then download it.

Advantages:

• Can save multiple formats

• Image stays on scope if needed

• Can verify file exists before download

> 💡 **Which to Use?**
> 
> Hardcopy is simpler and faster for one-off screenshots. Filesystem is better if you need to save multiple images or keep them on the scope.

