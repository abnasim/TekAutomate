# Pro-Tip: Always Use InkSaver

**Category:** measurements_commands
**ID:** inksaver_guide

---


## The InkSaver Command


### Why It Matters

• Black backgrounds waste printer toner

• White backgrounds look professional in reports

• Better contrast when printed

• Standard practice in technical documentation

> 💡 **Always Enable**
> 
> Make InkSaver part of your standard screenshot workflow. It's a simple command that makes a big difference in document quality.

