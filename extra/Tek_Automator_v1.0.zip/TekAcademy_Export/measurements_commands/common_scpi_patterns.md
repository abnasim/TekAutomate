# Common SCPI Patterns: Reusable Command Patterns and Templates

**Category:** measurements_commands
**ID:** common_scpi_patterns

---


## Reusable SCPI Patterns for Tektronix Instruments

These common patterns will save you time when automating Tektronix oscilloscopes.


### 2. Acquisition Pattern


### 3. Measurement Pattern


### 4. Trigger Setup Pattern


### 5. Screenshot Pattern


### 6. Multi-Channel Pattern


### 7. Waveform Export Pattern

