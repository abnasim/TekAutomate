# Why Use Binary Waveform Transfer?

**Category:** measurements_commands
**ID:** binary_vs_ascii

---

Problems:

• Large file sizes

RIBinary sends data as raw bytes. Much faster and exact precision.

Advantages:

• Smaller data size

• Less CPU usage

> ⚠️ **Always Use Binary**
> 
> For any serious automation, always use RIBinary format. ASCII is only useful for debugging or one-off manual queries.

