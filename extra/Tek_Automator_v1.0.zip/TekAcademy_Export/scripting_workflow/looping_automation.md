# Looping/Automation: Capturing 100 Times

**Category:** scripting_workflow
**ID:** looping_automation

---


## Wrapping Generated Code in a Loop

To capture data multiple times, wrap the generated workflow in a loop:

