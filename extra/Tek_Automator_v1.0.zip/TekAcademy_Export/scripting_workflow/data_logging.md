# Data Logging: Saving Results to CSV

**Category:** scripting_workflow
**ID:** data_logging

---


## Modifying Scripts for Data Logging

Add CSV logging to track measurements over time:

> 💡 **CSV Format**
> 
> CSV files are easy to open in Excel, Python pandas, or any data analysis tool. Include timestamps for time-series analysis.

