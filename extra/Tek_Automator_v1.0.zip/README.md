# Tek Automator - Tektronix Instrument Automation Tool

## 🚀 Quick Start

### First Time Setup

1. **Install Node.js** (if not already installed)
   - **Option A:** When running `SETUP.bat`, choose option [1] to install via Windows Package Manager (winget) - automatic installation
   - **Option B:** Download from https://nodejs.org/ (LTS version recommended)
   - After installation, close and reopen your command prompt (or restart computer)

2. **Run Setup**
   - Double-click `SETUP.bat`
   - Wait 2-3 minutes for dependencies to install
   - You only need to do this once

3. **Start Application**
   - Double-click `START.bat`
   - Browser will open automatically at http://localhost:3000

That's it! 🎉

---

## 📋 What This Tool Does

- **Visual Workflow Builder** - Drag-and-drop interface for creating instrument automation workflows
- **Comprehensive SCPI Command Library** - 4000+ SCPI commands for Tektronix oscilloscopes
  - MSO 2/4/5/6/7 Series commands
  - DPO 5K/7K/70K Series commands
  - 50,000+ tm_devices command combinations with full API tree
  - AWG, AFG, SMU, DPOJet, TekExpress commands
- **Multiple Backend Support** - PyVISA, tm_devices, VXI-11, and TekHSI
- **Python Export** - Generate ready-to-run Python scripts
- **Template Library** - Pre-built templates for common workflows
- **Flow Designer (BETA/POC)** - Advanced visual flow builder with conditions, loops, and groups
  - ⚠️ **Note:** The Flow Designer is currently in BETA and is a Proof of Concept (POC). Some features may be experimental or incomplete.

---

## 💻 System Requirements

- **OS:** Windows 10/11
- **Node.js:** Version 16 or higher (LTS recommended)
- **Disk Space:** 500MB free
- **Browser:** Modern browser (Chrome, Edge, Firefox)
- **Network:** Internet connection required for first-time setup

---

## 🐛 Troubleshooting

### "npm is not recognized" or "Node.js is not installed"
**Solution:** 
- When running `SETUP.bat`, choose option [1] to install Node.js via winget (automatic)
- Or choose option [2] to download the installer
- After installation, **close this window and open a NEW command prompt**, then run `SETUP.bat` again
- This is required because PATH changes need a new terminal session

### "Port 3000 already in use"
**Solution:**
- Close other applications using port 3000
- Or edit `START.bat` and add `set PORT=3001` before `npm start`

### "Dependencies not installing"
**Solution:**
- Check your internet connection
- Try running: `npm install --legacy-peer-deps`
- Delete `node_modules` folder and run `SETUP.bat` again

### "Cannot find module" errors
**Solution:**
- Run `SETUP.bat` again to reinstall dependencies
- Make sure you're in the correct folder when running the batch files

### Application won't start
**Solution:**
- Make sure `node_modules` folder exists (run `SETUP.bat` if missing)
- Check that all files are in the correct folders
- Open browser console (F12) to see error messages

---

## 📚 Documentation

All documentation is located in the `docs/` folder:

- **Backend Selection Guide:** See `docs/BACKEND_GUIDE.md` for detailed information about choosing the right backend (PyVISA, tm_devices, VXI-11, TekHSI)
- **Technical Architecture:** See `docs/TECHNICAL_ARCHITECTURE.md` for detailed information about how the app handles connections, multiple instruments, SCPI commands, and backend mixing
- **In-App Help:** The application includes built-in help and examples

---

## 📁 Project Structure

```
Tek_Automator/
├── SETUP.bat              # First-time setup script
├── START.bat              # Launch application
├── README.md              # This file (quick start guide)
├── package.json           # Node.js dependencies
├── tsconfig.json          # TypeScript configuration
├── docs/                  # Documentation folder
│   ├── BACKEND_GUIDE.md   # Backend selection guide
│   └── TECHNICAL_ARCHITECTURE.md  # Technical documentation
├── scripts/               # Utility scripts
│   ├── CLEANUP.bat        # Cleanup script for outdated files
│   └── ultimate-installer.bat  # Alternative installer (legacy)
├── public/
│   ├── commands/          # SCPI command library (15 JSON files)
│   └── templates/         # Workflow templates (5 JSON files)
└── src/
    ├── App.tsx            # Main application
    ├── index.tsx          # React entry point
    └── components/        # React components
        └── FlowBuilder/   # Flow Designer (BETA/POC)
```

---

## 🔄 Updating the Application

To update to a new version:
1. Extract the new ZIP file to a new folder
2. Run `SETUP.bat` in the new folder
3. Your old workflows and templates are saved in the browser, so they'll still be available

## 📦 Creating Distribution ZIP

**Important:** When creating a ZIP file for distribution, **DO NOT include `node_modules`** folder!

The `node_modules` folder is ~800MB and should NOT be included. Users will install dependencies by running `SETUP.bat`.

To create a proper distribution ZIP:
1. Run `scripts\CREATE_DISTRIBUTION.bat` - This will create a clean ZIP file excluding `node_modules`, `logs`, and other unnecessary files
2. The resulting ZIP should be ~60-80 MB

**Expected ZIP size:** ~60-80 MB (due to comprehensive command library)
- Command JSON files alone are ~58 MB (4000+ commands, 50k+ tm_devices combinations)
- Source code + docs: ~5-10 MB
- If ZIP is 200MB+, `node_modules/` got included by mistake

**What's included in the distribution ZIP:**
- ✅ All source code (`src/` folder)
- ✅ All command JSON files (`public/commands/` - ~58 MB of SCPI command data)
- ✅ All templates (`public/templates/`)
- ✅ Configuration files (`package.json`, `tsconfig.json`)
- ✅ Batch files (`SETUP.bat`, `START.bat`)
- ✅ Documentation (`docs/` folder)
- ✅ Public assets (`public/` folder)
- ❌ `node_modules/` (users install via SETUP.bat)
- ❌ `logs/` folder
- ❌ `build/` folder

---

## 💡 Tips

- **Start with Templates:** Use the built-in templates as starting points
- **Save Your Work:** Workflows are saved in your browser automatically
- **Export Scripts:** Generated Python scripts are saved to your Downloads folder
- **Search Commands:** Use the search bar in the Commands tab to quickly find what you need
- **Flow Designer:** The Flow Designer is in BETA - use the traditional workflow builder for production workflows

---

## 🆘 Support

For issues or questions:
- Check the Troubleshooting section above
- Review `docs/BACKEND_GUIDE.md` for backend-specific questions
- Review `docs/TECHNICAL_ARCHITECTURE.md` for technical details
- Contact your team lead or IT support

---

## 📝 Version

Current Version: 1.0.0

**Note:** Flow Designer is BETA/POC - features may change in future versions.

---

## 📄 License

Internal use only. Do not distribute outside your organization.

